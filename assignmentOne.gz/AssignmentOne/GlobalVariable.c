#include <stdio.h>

int num = 10;

int main()
{
	printf("The global variable num is %d\n", num);
	return 0;
}
