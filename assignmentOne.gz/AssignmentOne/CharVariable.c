#include <stdio.h>

int main()
{
	char c = 'h';
	printf("%c\n", c);
	return 0;
}
