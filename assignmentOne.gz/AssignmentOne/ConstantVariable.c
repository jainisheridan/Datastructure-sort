#include <stdio.h>

const double pi = 3.14;

int main()
{
	printf("The constant varible pi is %.2f\n", pi);
	return 0;
}
