#include <stdio.h>
int main()
{
	char s[] = "Hello Class.....";
	printf("%s\n", s);
	return 0;
}
