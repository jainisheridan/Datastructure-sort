#include <stdio.h>

int main()
{
	int a = 10;
	printf("%d\n", a);
	return 0;
}
