#include <stdio.h>

int main()
{
	int num;
	printf("please enter an integer: ");
	scanf("%d", &num);
	printf("The input is %d\n", num);
	return 0;
}
