#include<stdio.h>

int main()
{
	double pi = 3.1415926;
	printf("%.4f\n", pi);
	return 0;
}
